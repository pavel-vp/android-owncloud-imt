package com.mobile_me.imtv_player.service;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.mobile_me.imtv_player.model.MTPlayList;
import com.mobile_me.imtv_player.model.MTPlayListRec;

/**
 * Created by pasha on 8/27/16.
 */
public class MTLoaderManager implements IMTCallbackEvent {
    static MTLoaderManager instance;
    MTOwnCloudHelper helper;
    MTPlayListManager mPlayListManager;

    public static MTLoaderManager getInstance(Context ctx) {
        if (instance == null) {
            instance = new MTLoaderManager(ctx);
        }
        return instance;
    }

    private Context ctx;

    public MTLoaderManager(Context ctx) {
        this.ctx = ctx;
        helper = new MTOwnCloudHelper(ctx, this);
        mPlayListManager = MTPlayListManager.getInstance(ctx);
        log("helper created");

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    helper.loadPlayListFromServer();
                    try {
                        Thread.sleep(60000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }


    @Override
    public void onPlayListLoaded(MTPlayList playListNew) {
        log("onPlayListLoaded success. playListNew.size="+playListNew.getPlaylist().size());
        //Toast.makeText(this, "Плейлист загружен", Toast.LENGTH_SHORT).show();
        mPlayListManager.mergeAndSavePlayList(playListNew);
        // запустить загрузку файлов из плейлиста при необходимости
        MTPlayListRec fileToLoad = mPlayListManager.getNextFileToLoad();
        if (fileToLoad != null) {
            helper.loadVideoFileFromPlayList(fileToLoad);
        }
    }

    @Override
    public void onVideoFileLoaded(MTPlayListRec file) {
        log("onVideoFileLoaded start. name="+file.getFilename());
        //Toast.makeText(ctx, "Файл "+file.getFilename()+" загружен", Toast.LENGTH_SHORT).show();
        // найти в списке и проавпдейтить статус
        mPlayListManager.setFileStateFlag(file, MTPlayListRec.STATE_UPTODATE);
        // стартовать проверку на загрузку других файлов из плейлиста TODO: тут? или после загрузки плейлиста кажый раз проверять по 1му файлу?
//        doLoadNextVideoFiles();
    }

    @Override
    public void onError(int mode) {
      // тут ничего не делаем... запустится сам по тамеру в следующий раз
    }

    public void log(String s) {
        Log.d("IMTV_LOG", s);
    }
}
