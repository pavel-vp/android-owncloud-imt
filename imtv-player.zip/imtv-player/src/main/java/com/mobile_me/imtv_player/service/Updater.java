package com.mobile_me.imtv_player.service;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.Writer;
import java.net.URL;
import java.net.URLConnection;

/**
 * Created by pasha on 7/26/16.
 */
public class Updater {

    Context ctx;
    public Updater(Context ctx) {
        this.ctx = ctx;
    }

    public boolean downloadNewVersion(final String remotePath, final String fileName, final String localDir) {
        boolean res = false;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {

                    URL url = new URL(remotePath + "/" + fileName);
                    final URLConnection conn = url.openConnection();
                    conn.connect();


                    File outputDirs = new File(localDir);
                    outputDirs.mkdirs();
                    String localFileName = "tmp.apk";
                    File outputFile = new File(localDir, localFileName);
                    FileOutputStream fos = new FileOutputStream(outputFile);
                    //начинаем закачку в буфер

                    InputStream is = conn.getInputStream();

                    byte[] buffer = new byte[1024];
                    int len1 = 0;
                    while ((len1 = is.read(buffer)) != -1) {
                        fos.write(buffer, 0, len1);
                    }
                    fos.close();
                    is.close();
                    Runtime.getRuntime().exec("chmod 777 " + outputFile);

                    // запустить установку
                    if (outputFile.exists()) {
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setDataAndType(Uri.fromFile(outputFile), "application/vnd.android.package-archive");
                        ctx.startActivity(intent);
                        //res = true;
                    }

                } catch (Exception e) {
                    //res = false;
                    e.printStackTrace();
                }
            }
        }).start();
        return res;
    }

}
