package com.mobile_me.imtv_player.service;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobile_me.imtv_player.R;
import com.mobile_me.imtv_player.dao.Dao;
import com.mobile_me.imtv_player.model.MTPlayList;
import com.mobile_me.imtv_player.model.MTPlayListRec;
import com.owncloud.android.lib.common.OwnCloudClient;
import com.owncloud.android.lib.common.OwnCloudClientFactory;
import com.owncloud.android.lib.common.OwnCloudCredentialsFactory;
import com.owncloud.android.lib.common.network.OnDatatransferProgressListener;
import com.owncloud.android.lib.common.operations.OnRemoteOperationListener;
import com.owncloud.android.lib.common.operations.RemoteOperation;
import com.owncloud.android.lib.common.operations.RemoteOperationResult;
import com.owncloud.android.lib.resources.files.DownloadRemoteFileOperation;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by pasha on 7/21/16.
 */
public class MTOwnCloudHelper implements OnRemoteOperationListener, OnDatatransferProgressListener  {

    private static final String LOG_TAG = MTOwnCloudHelper.class.getCanonicalName();

    private static final int STATE_UNKNOWN = 0;
    private static final int STATE_LOADPLAYLIST = 1;
    private static final int STATE_LOADVIDEOFILE = 2;

    Context ctx;
    private OwnCloudClient mClient;
    private IMTCallbackEvent cb;
    Handler mHandler = new Handler();
    ObjectMapper mapper = new ObjectMapper();

    private int state = STATE_UNKNOWN;
    Dao dao;
    MTPlayListRec fileToLoad;


    public MTOwnCloudHelper(Context ctx, IMTCallbackEvent cb) {
        this.ctx = ctx;
        this.cb = cb;
        dao = Dao.getInstance(ctx);
        Uri serverUri = Uri.parse(ctx.getString(R.string.server_base_url));
        mClient = OwnCloudClientFactory.createOwnCloudClient(serverUri, ctx, true);
        mClient.setCredentials(
                OwnCloudCredentialsFactory.newBasicCredentials(
                        ctx.getString(R.string.username),
                        ctx.getString(R.string.password)
                )
        );
        mClient.getParams().setSoTimeout(30 * 60 * 1000);
    }

    public void loadPlayListFromServer() {
        if (state == STATE_UNKNOWN) {
            state = STATE_LOADPLAYLIST;
            DownloadRemoteFileOperation downloadOperation = new DownloadRemoteFileOperation(dao.getRemotePlayListFilePath(), dao.getDownFolder().getAbsolutePath());
            downloadOperation.addDatatransferProgressListener(this);
            downloadOperation.execute(mClient, this, mHandler);
            log("loadPlayListFromServer started=" + dao.getRemotePlayListFilePath() + " to " + dao.getDownFolder().getAbsolutePath());
        }
    }

    @Override
    public void onTransferProgress(long progressRate, long totalTransferredSoFar, long totalToTransfer, String fileAbsoluteName) {
//        cb.log("onTransferProgress="+fileAbsoluteName+ "  "+totalTransferredSoFar);
    }

    @Override
    public void onRemoteOperationFinish(RemoteOperation operation, RemoteOperationResult result) {
        if (!result.isSuccess()) {
          //  Toast.makeText(ctx, R.string.todo_operation_finished_in_fail, Toast.LENGTH_SHORT).show();
            Log.e(LOG_TAG, result.getLogMessage(), result.getException());
            log("onRemoteOperationFinish error="+result.getLogMessage());
            state = STATE_UNKNOWN;
            cb.onError(state);
/*            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            // нужно запустить заново TODO: не надо же?
            switch (state) {
                case STATE_LOADPLAYLIST:
                    loadPlayListFromServer();
                    break;
                case STATE_LOADVIDEOFILE:
                    loadVideoFileFromPlayList(mPlayList);
                    break;
            }*/
        } else if (operation instanceof DownloadRemoteFileOperation ) {
            log("onRemoteOperationFinish success. state="+state);
            switch (state) {
                case STATE_LOADPLAYLIST:
                    // загрузили плейлист
                    MTPlayList playList = null;
                    try {
                        List<LinkedHashMap<String, String>> r = mapper.readValue(new File(dao.getDownFolder().getAbsolutePath(), dao.getRemotePlayListFilePath()), List.class);

                        playList = new MTPlayList();
                        for (LinkedHashMap<String, String> m : r) {
                            MTPlayListRec rec = new MTPlayListRec();
                            rec.setId(Long.parseLong(m.get("id")));
                            rec.setFilename(m.get("filename"));
                            rec.setSize(Long.parseLong(m.get("size")));
                            rec.setDuration(Long.parseLong(m.get("duration")));
                            playList.getPlaylist().add(rec);
                        }
                        //playList = mapper.readValue(new File(dao.getDownFolder().getAbsolutePath(), dao.getRemotePlayListFilePath()), MTPlayList.class);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    state = STATE_UNKNOWN;
                    cb.onPlayListLoaded(playList);
                    break;
                case STATE_LOADVIDEOFILE:
                    state = STATE_UNKNOWN;
                    // загрузили файл из плейлиста
                    // событие обработчик
                    cb.onVideoFileLoaded(fileToLoad);
            }
        } else {
            //Toast.makeText(this, R.string.todo_operation_finished_in_success, Toast.LENGTH_SHORT).show();
        }
    }

    public void loadVideoFileFromPlayList(MTPlayListRec file) {
        if (state == STATE_UNKNOWN) {
            state = STATE_LOADVIDEOFILE;
            fileToLoad = file;
            log("loadVideoFileFromPlayList fileToLoad=" + fileToLoad.getFilename());
            DownloadRemoteFileOperation downloadOperation = new DownloadRemoteFileOperation(dao.getRemoteVideoDir() + fileToLoad.getFilename(), dao.getDownFolder().getAbsolutePath());
            downloadOperation.addDatatransferProgressListener(this);
            downloadOperation.execute(mClient, this, mHandler);
            log("loadVideoFileFromPlayList downloadOperation.executed");
        }
    }

    private void log(String s) {
        Log.d("IMTV", s);
    }

    public int getState() {
        return state;
    }

}
