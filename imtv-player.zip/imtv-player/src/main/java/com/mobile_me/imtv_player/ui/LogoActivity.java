package com.mobile_me.imtv_player.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobile_me.imtv_player.R;
import com.mobile_me.imtv_player.model.MTPlayList;
import com.mobile_me.imtv_player.model.MTPlayListRec;
import com.mobile_me.imtv_player.service.IMTCallbackEvent;
import com.mobile_me.imtv_player.service.MTOwnCloudHelper;
import com.mobile_me.imtv_player.service.MTPlayListManager;
import com.mobile_me.imtv_player.service.tasks.CheckPlayListLocalTask;

/**
 * Created by pasha on 8/13/16.
 */
public class LogoActivity extends AbstractBaseActivity implements IMTCallbackEvent {

    MTOwnCloudHelper helper;
    ObjectMapper mapper = new ObjectMapper();
    MTPlayList playListTmp;
    MTPlayListManager playListManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logo);
        helper = new MTOwnCloudHelper(this, this);
        playListManager = MTPlayListManager.getInstance(this);

    }

    @Override
    protected void onStart() {
        super.onStart();
        // стартовать task по анализу доступности данных для проигрывания локально, чтобы не ждать загрузки
        runTaskInBackgroundNoDialog(new CheckPlayListLocalTask());

    }

    private void startMainActivity() {
        // есть локальный плейлист - проверяем наличие файлов на диске
        Intent in = new Intent();
        in.setClass(this, MainActivity.class);
        startActivity(in);
        this.finish(); // закрываем это активити
    }

    @Override
    protected void onBackgroundTaskComplete(int taskId, Runnable task) {
        super.onBackgroundTaskComplete(taskId, task);
        if (task instanceof CheckPlayListLocalTask) {
            boolean r = ((CheckPlayListLocalTask) task).result;
            if (r) {
                playListManager.mergeAndSavePlayList(((CheckPlayListLocalTask) task).playList);
                startMainActivity();
            } else {
                // нет локального плейлиста - запускаем задачу первоначальной загрузки в текущем активити (пусть будет логотип)
                helper.loadPlayListFromServer();
            }
        }
    }

    @Override
    public void onPlayListLoaded(MTPlayList playListNew) {
        // плейлист загружен, запускаем загрузку первого файла
        log("onPlayListLoaded success. playListNew.size="+playListNew.getPlaylist().size());
        //Toast.makeText(this, "Плейлист загружен", Toast.LENGTH_SHORT).show();
        // запустить загрузку файлов из плейлиста
        playListTmp = playListNew;
        playListManager.mergeAndSavePlayList(playListNew);
        MTPlayListRec fileToLoad = playListManager.getNextFileToLoad();
        if (fileToLoad != null) {
            helper.loadVideoFileFromPlayList(fileToLoad);
        } else {
             // если все файлы актуальные вызываем активити
            startMainActivity();
        }
    }

    @Override
    public void onVideoFileLoaded(MTPlayListRec file) {
        playListManager.setFileStateFlag(file, MTPlayListRec.STATE_UPTODATE);
        startMainActivity();
    }

    @Override
    public void onError(int mode) {
        // запустить заново загрузку
        runTaskInBackgroundNoDialog(new CheckPlayListLocalTask());
    }

    private void log(String s) {
        Log.d("IMTV", s);
    }

}
