package com.mobile_me.imtv_player.ui;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.TextView;

import com.mobile_me.imtv_player.R;
import com.mobile_me.imtv_player.dao.Dao;
import com.mobile_me.imtv_player.model.MTPlayListRec;
import com.mobile_me.imtv_player.service.MTLoaderManager;
import com.mobile_me.imtv_player.service.MTPlayListManager;

import java.io.IOException;

import static java.util.Collections.swap;

public class MainActivity extends Activity implements
        MediaPlayer.OnPreparedListener,
        MediaPlayer.OnCompletionListener {

    MediaPlayer mediaPlayer = null;
    MediaPlayer mediaPlayer2 = null;
    SurfaceView sv;
    SurfaceView sv2;
    TextView tvLog;
    boolean isInPreparing = false;
    boolean isInPreparing2 = false;
    MTLoaderManager loaderManager;
    MTPlayListManager playListManager;
    Dao dao;
    private boolean isActive = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvLog = (TextView) findViewById(R.id.tvLog);
        sv = (SurfaceView) findViewById(R.id.surfaceView);
        sv2 = (SurfaceView) findViewById(R.id.surfaceView2);

        loaderManager = MTLoaderManager.getInstance(this);
        playListManager = MTPlayListManager.getInstance(this);
        dao = Dao.getInstance(this);
        SurfaceHolder holder = sv.getHolder();
        holder.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                mediaPlayer.setDisplay(holder);
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                mediaPlayer.setDisplay(null);
            }
        });
        holder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
        }
        mediaPlayer.setOnCompletionListener(this);
        mediaPlayer.setOnPreparedListener(this);
        loaderManager.log("mediaPlayer created");
        SurfaceHolder holder2 = sv2.getHolder();
        holder2.addCallback(new SurfaceHolder.Callback() {
            @Override
            public void surfaceCreated(SurfaceHolder holder) {
                mediaPlayer2.setDisplay(holder);
            }

            @Override
            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {

            }

            @Override
            public void surfaceDestroyed(SurfaceHolder holder) {
                mediaPlayer2.setDisplay(null);
            }
        });
        holder2.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
        if (mediaPlayer2 == null) {
            mediaPlayer2 = new MediaPlayer();
        }
        mediaPlayer2.setOnCompletionListener(this);
        mediaPlayer2.setOnPreparedListener(this);
        loaderManager.log("mediaPlayer2 created");
        // возможно плейлист передан нам в активити FIXME: изменить, показывать старторвую форму просто до те пор, пока не скачается какой-нить файл
/*        Bundle ext = getIntent().getExtras();
        if (ext != null) {
            MTPlayList playListNew = null;
            String s = ext.getString(PLAYLIST_EXTRA);
            try {
                playListNew = mapper.readValue(s, MTPlayList.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
            mergePlayList(playListNew);
        }
*/


/*        Updater upd = new Updater(this);
        File downFolderNewVer = this.getExternalFilesDir("newversion");

        upd.downloadNewVersion("http://showboxa.com/wp-content/uploads/apks", "Showbox%204.08.apk", downFolderNewVer.getAbsolutePath());
*/

    }

    @Override
    protected void onPause() {
        super.onPause();
        isInPreparing = false;
        mediaPlayer.reset();
        isInPreparing2 = false;
        mediaPlayer2.reset();
        isActive = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        isActive = true;
        // запуск проигрывания сразу
        playNextVideoFile(mediaPlayer);
        playNextVideoFile(mediaPlayer2);
    }


    @Override
    public void onCompletion(MediaPlayer mp) {
        // попробовать запустить далее по списку следующий файл (или снова первый)
        loaderManager.log("mediaPlayer.onCompletion called");
        mp.reset();
        playNextVideoFile(mp);
    }

    @Override
    public void onPrepared(MediaPlayer mp) {
        loaderManager.log("mediaPlayer.prepareAsync finished, run Start");
        mp.start();
        if (mp == mediaPlayer) {
            isInPreparing = false;
        } else {
            isInPreparing2 = false;
        }
    }

    public void playNextVideoFile(MediaPlayer mp) {
        loaderManager.log("playNextVideoFile started");
        if (mp.isPlaying() || (mp == mediaPlayer && isInPreparing) || (mp == mediaPlayer2 && isInPreparing2) || !isActive) {
            loaderManager.log("playNextVideoFile playing exit");
            return;
        }

        String filePathToPlay = null;
        boolean forcedPlay = false;

        if (mp == mediaPlayer) {
            MTPlayListRec found = null;
            // взять из плейлиста следующий непроигранный
            if (playListManager.getPlayList() != null) {
                found = playListManager.getNextVideoFileForPlay(forcedPlay);
            }
            // если непроигранного нет - значит все проиграли, запустим поиск с принудительнм возвращением хотя бы одного,
            // при этом по логике отбора файла - он должен вернуть хотя бы один, и возможно сбросить все состояния проигрывания.
            if (found == null) {
                forcedPlay = true;
                found = playListManager.getNextVideoFileForPlay(forcedPlay);
            }
            loaderManager.log("playList.getNextVideoFileForPlay=" + dao.getDownVideoFolder() + found.getFilename() + " (" + found.getId() + ")");
            filePathToPlay = dao.getDownVideoFolder() + found.getFilename();
        } else {
            MTPlayListRec found = playListManager.getRandomFile();
            filePathToPlay = dao.getDownVideoFolder() + found.getFilename();
        }

        if (filePathToPlay != null && isActive) {
            // запустить проигрывание этого файла
            try {
                mp.setDataSource(filePathToPlay);
                mp.prepareAsync();
                if (mp == mediaPlayer) {
                    isInPreparing = true;
                } else {
                    isInPreparing2 = false;
                }
                loaderManager.log("mediaPlayer.prepareAsync  started");
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
        if (forcedPlay) {
            loaderManager.log("playList.getNextVideoFileForPlay="+null);
            // запустить загрузку плейлиста TODO: не надо же уже?
            //helper.loadPlayListFromServer();
        }
    }
}
