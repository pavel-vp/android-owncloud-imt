package com.mobile_me.imtv_player.dao;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.support.v4.content.ContextCompat;
import android.support.v4.os.EnvironmentCompat;
import android.telephony.TelephonyManager;

import com.mobile_me.imtv_player.R;
import com.mobile_me.imtv_player.model.MTPlayList;
import com.mobile_me.imtv_player.model.MTPlayListRec;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Отвечает за локальные данные
 * Created by pasha on 8/14/16.
 */
public class Dao {

    public final static String DB_NAME = "imtv_db";
    public final static int DB_VERSION = 1;
    public final static String PATH_KEY = "path_key";

    private Logger logger = Logger.getLogger("DAO");
    private static Dao instance;
    private Context ctx;

    private PlayListDBHelper mPlayListDBHelper;
    private SharedPreferences mSharedPreferences;
    File downFolder;
    String remotePlayListFilePath;
    String remoteVideoDir;
    String downVideoFolder;
    String deviceId;


    public static Dao getInstance(Context ctx) {
        if (instance == null) {
            instance = new Dao(ctx);
        }
        return instance;
    }

    public Dao(Context ctx) {
        this.ctx = ctx;
        this.mPlayListDBHelper = new PlayListDBHelper(this.ctx);
        this.mSharedPreferences = ctx.getSharedPreferences("settings", Activity.MODE_PRIVATE);

        TelephonyManager telephonyManager = (TelephonyManager)ctx.getSystemService(Context.TELEPHONY_SERVICE);
        deviceId = telephonyManager.getDeviceId();
deviceId = "352005048247251";

//        downFolder = act.getExternalFilesDir(act.getString(R.string.download_folder_path));
        downFolder = definePathToVideo();
        downFolder.mkdir();
        remotePlayListFilePath = "/" + String.format(ctx.getString(R.string.playlist_filepath), deviceId);
        remoteVideoDir = "/" + ctx.getString(R.string.video_dir) ;
        // создадим директории
        File dv = new File(downFolder, ctx.getString(R.string.video_dir));
        dv.mkdir();
        downVideoFolder = dv.getAbsolutePath();
        File dp = new File(new File(downFolder, String.format(ctx.getString(R.string.playlist_filepath), deviceId)).getParent());
        dp.mkdir();

    }


    public File definePathToVideo() {
        File path = null;
        String p = mSharedPreferences.getString(PATH_KEY, null);
        if (p != null) {
            path = new File(p);
        }
        // если пусто
        if (p == null || !Environment.MEDIA_MOUNTED.equals(EnvironmentCompat.getStorageState(path))
                || Environment.MEDIA_MOUNTED_READ_ONLY.equals(EnvironmentCompat.getStorageState(path))
                || !path.exists()
                || !path.canWrite() ) {
            path = getBestAvailableFilesRoot();
            SharedPreferences.Editor ed = mSharedPreferences.edit();
            ed.putString(PATH_KEY, path.getAbsolutePath());
            ed.commit();
        }
        path.mkdirs();
        return path;
    }

    public File getBestAvailableFilesRoot() {
        // FIXME: переделать на приоритеты (usb - 1, ext_sd - 2, emulated - 3, если нет ничего - то локальное)

        File[] roots = ContextCompat.getExternalFilesDirs(ctx, null);
        if (roots != null) {
            File best = null;
            for (File root : roots) {
                if (root == null) {
                    continue;
                }

                if (Environment.MEDIA_MOUNTED.equals(EnvironmentCompat.getStorageState(root))
                        &&  !Environment.MEDIA_MOUNTED_READ_ONLY.equals(EnvironmentCompat.getStorageState(root))
                        && root.exists()
                        && root.canWrite() ) {
                    logger.log(Level.WARNING, "root="+root);
                    long freeSize = root.getFreeSpace();
                    if (best == null || freeSize > best.getFreeSpace()) {
                        best = root;
                    }
                }
            }
            if (best != null) {
                return best;
            }
        }
        // Worst case, resort to internal storage
        return ctx.getFilesDir();
    }

    public PlayListDBHelper getPlayListDBHelper() {
        return mPlayListDBHelper;
    }

    public String getDownVideoFolder() {
        return downVideoFolder;
    }


    public String getRemotePlayListFilePath() {
        return remotePlayListFilePath;
    }


    public File getDownFolder() {
        return downFolder;
    }


    public String getRemoteVideoDir() {
        return remoteVideoDir;
    }

    public String getDeviceId() {
        return deviceId;
    }

}
