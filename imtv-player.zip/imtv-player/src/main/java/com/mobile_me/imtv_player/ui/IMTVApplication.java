package com.mobile_me.imtv_player.ui;

import android.app.Application;
import android.os.Handler;

/**
 * Created by pasha on 8/17/16.
 */
public class IMTVApplication extends Application {
    private static IMTVApplication instance;

    protected Handler handler = new Handler();


    public static IMTVApplication getInstance() {
        return instance;
    }

    public IMTVApplication() {
        super();
        instance = this;
    }

}
