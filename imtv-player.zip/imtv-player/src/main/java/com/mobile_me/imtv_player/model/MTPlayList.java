package com.mobile_me.imtv_player.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by pasha on 7/21/16.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class MTPlayList implements Serializable {

    private List<MTPlayListRec> playlist = new ArrayList<>();

    public List<MTPlayListRec> getPlaylist() {
        return playlist;
    }

    public MTPlayListRec searchById(Long id) {
        if (playlist.size() > 0) {
            for (MTPlayListRec r : playlist) {
                if (r.getId() == id) {
                    return r;
                }
            }
        }
        return null;
    }
}
