package com.mobile_me.imtv_player.service;

import com.mobile_me.imtv_player.model.MTPlayList;
import com.mobile_me.imtv_player.model.MTPlayListRec;

/**
 * Created by pasha on 7/21/16.
 */
public interface IMTCallbackEvent {
    void onPlayListLoaded(MTPlayList playList);
    void onVideoFileLoaded(MTPlayListRec file);
    void onError(int mode);
}
